# fiber-svelte
A template to start building websites with Go with Fiber as the back-end and Svelte for the front-end.  
Make sure to run `npm install` to download all dependencies.